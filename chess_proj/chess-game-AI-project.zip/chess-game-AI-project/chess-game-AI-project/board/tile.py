class Tile:

    pieceonTile= None
    tileCorrdinate= None

    def __init__(self,coordinate, piece):
        self.tileCorrdinate=coordinate
        self.pieceonTile=piece