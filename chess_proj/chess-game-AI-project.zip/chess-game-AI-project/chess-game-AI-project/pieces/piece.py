class piece:

    def __intit__(self):
        pass



